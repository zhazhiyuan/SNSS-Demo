function col_no = ComputeColNo(block_no,wideth)

 col_no = ceil(double(block_no)/wideth);
